@echo off
chcp 936 >nul
title NX模仿CAD快捷键插件 - 自动安装器
mode con cols=80 lines=20

:: ==================== 第一步：提权（管理员权限）====================
>nul 2>&1 "%SYSTEMROOT%\system32\cacls.exe" "%SYSTEMROOT%\system32\config\system"
if '%errorlevel%' NEQ '0' (
    echo 正在请求管理员权限...
    goto UACPrompt
) else ( goto gotAdmin )

:UACPrompt
    echo Set UAC = CreateObject^("Shell.Application"^) > "%temp%\getadmin.vbs"
    echo UAC.ShellExecute "%~s0", "", "", "runas", 1 >> "%temp%\getadmin.vbs"
    "%temp%\getadmin.vbs"
    exit /B

:gotAdmin
    if exist "%temp%\getadmin.vbs" ( del "%temp%\getadmin.vbs" )
    pushd "%CD%"
    CD /D "%~dp0"

:: ==================== 第二步：永久设置环境变量 ====================
echo 正在永久设置UGII_USER_DIR环境变量...
:: 写入系统环境变量（HKLM=系统级，所有用户生效）
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v "UGII_USER_DIR" /t REG_EXPAND_SZ /d "D:\Cadshortcutskey" /f >nul
reg add "HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Environment" /v "CADKEY_DIR" /t REG_EXPAND_SZ /d "D:\Cadshortcutskey" /f >nul
if errorlevel 1 (
    echo ❌ 环境变量设置失败！请手动以管理员身份运行此脚本。
    pause >nul
    exit /b
)
echo ✅ 永久环境变量设置完成！
echo UGII_USER_DIR = D:\Cadshortcutskey
echo CADKEY_DIR= D:\Cadshortcutskey
:: ==================== 第三步：创建插件目录+复制文件 ====================
echo.
echo 📁 正在创建插件目录...
if not exist "D:\Cadshortcutskey" md "D:\Cadshortcutskey"

echo 📤 正在复制插件文件...
copy /Y "%~dp0\data\button_id.ini" "D:\Cadshortcutskey\data" >nul
copy /Y "%~dp0\data\Cadshortcutskey.macro" "D:\Cadshortcutskey\data" >nul
copy /Y "%~dp0\data\chick.ini" "D:\Cadshortcutskey\data" >nul
copy /Y "%~dp0\data\nx_cad_shortcut.nxkey" "D:\Cadshortcutskey\data" >nul
copy /Y "%~dp0\startup\nx_cad_shortcut.dll" "D:\Cadshortcutskey\startup" >nul
copy /Y "%~dp0\startup\Cadshortcutskey.men" "D:\Cadshortcutskey\startup" >nul
if errorlevel 1 (
    echo ❌ 复制文件失败！请关闭NX后重试。
    pause >nul
    exit /b
)
echo ✅ 插件文件复制完成！
:: ==================== 第四步：安装完成提示 ====================
echo.
echo ==============================================
echo 🎉 安装成功！
echo 📌 插件目录：D:\Cadshortcutskey
echo 📌 许可文件：nx_cad_shortcut.nxkey（半年更新一次）
echo 📌 重启NX即可使用CAD快捷键！
echo ==============================================
echo.
pause >nul
exit /b